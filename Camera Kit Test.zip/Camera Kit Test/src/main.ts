import { bootstrapCameraKit } from '@snap/camera-kit';

(async function main() {
  const apiToken = 'eyJhbGciOiJIUzI1NiIsImtpZCI6IkNhbnZhc1MyU0hNQUNQcm9kIiwidHlwIjoiSldUIn0.eyJhdWQiOiJjYW52YXMtY2FudmFzYXBpIiwiaXNzIjoiY2FudmFzLXMyc3Rva2VuIiwibmJmIjoxNzIxMzIxMzA2LCJzdWIiOiI1OTM3NjdkMC01ZjU4LTRkMmEtYTA0Ni05NDlkMzI4YWNlMTF-U1RBR0lOR34wMjU5N2I2ZS1hYjhiLTQyY2EtYTQyZi1mYjY0ZDljMTRlNDAifQ.4aLW4TmXxLqAU-x1C8JMFbbF66N3PjN60l6IqI33gJw';
  const cameraKit = await bootstrapCameraKit({ apiToken });

  const liveRenderTarget = document.getElementById('canvas') as HTMLCanvasElement;
  const session = await cameraKit.createSession({liveRenderTarget});

  const mediaStream = await navigator.mediaDevices.getUserMedia({
    video:{
      facingMode: 'user'
    }
  })

  await session.setSource(mediaStream);
  await session.play();

  const lens = await cameraKit.lensRepository.loadLens('84f97e02-a563-4870-8314-9a2be5375cf6','32d71db8-8e60-4bf3-9139-5f32211ad7cd');
  await session.applyLens(lens);

})();


